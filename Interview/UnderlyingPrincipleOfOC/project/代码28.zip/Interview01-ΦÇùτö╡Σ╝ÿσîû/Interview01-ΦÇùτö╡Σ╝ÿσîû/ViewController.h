//
//  ViewController.h
//  Interview01-耗电优化
//
//  Created by MJ Lee on 2018/7/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

