//
//  MJPerson.m
//  Interview03-安装包瘦身
//
//  Created by MJ Lee on 2018/7/9.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson

@end
