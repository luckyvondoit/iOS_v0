//
//  MJHTTPTool.m
//  Interview08-分层设计
//
//  Created by MJ Lee on 2018/7/17.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJHTTPTool.h"

@implementation MJHTTPTool

+ (void)GET:(NSString *)URL params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    // 调用AFN
}

@end
