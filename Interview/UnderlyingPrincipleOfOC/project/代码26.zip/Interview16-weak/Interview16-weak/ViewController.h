//
//  ViewController.h
//  Interview16-weak
//
//  Created by MJ Lee on 2018/7/1.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

