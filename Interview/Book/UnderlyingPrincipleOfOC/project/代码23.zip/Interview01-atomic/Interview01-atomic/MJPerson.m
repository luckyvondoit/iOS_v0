//
//  MJPerson.m
//  Interview01-atomic
//
//  Created by MJ Lee on 2018/6/19.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson

//- (void)setName:(NSString *)name
//{
//    // 加锁
//    _name = name;
//    // 解锁
//}

//- (NSString *)name
//{
// 加锁
//    return _name;
// 解锁
//}

@end
